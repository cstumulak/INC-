<footer class="main-footer">
    <div class="pull-right hidden-xs">
    
    </div>
     <strong> <a href="https://www.facebook.com/photo/?fbid=5168221146597144&set=a.133535386732437&__tn__=%3C">Cj Shop</a></strong>
</footer>